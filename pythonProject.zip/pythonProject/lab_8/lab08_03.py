# -*- coding: utf-8 -*-
import simple_draw as sd

sd.resolution = (900, 600)

print('Цвета:\n 1. красный\n 2. оранжевый\n 3. желтый\n 4. зеленый\n 5. голубой\n 6. синий\n 7. фиолетовый')
color_num = input('Введите номер цвета ')

if int(color_num) > 7 or int(color_num) < 1:
    print('Вы ввели некорректный номер')

print('Фигуры:\n 1. треугольник\n 2. квадрат\n 3. пятиугольник\n 4. шестиугольник')
figure_num = input('Введите номер цвета ')

if int(figure_num) > 4 or int(figure_num) < 1:
    print('Вы ввели некорректный номер')

all_color = [sd.COLOR_RED, sd.COLOR_ORANGE, sd.COLOR_YELLOW, sd.COLOR_GREEN, sd.COLOR_CYAN, sd.COLOR_BLUE, sd.COLOR_PURPLE]


def geometric_figure (x2, y2, angle2, side_length2, m_n, n, m, m2, v, col):
    start_p = sd.get_point(x2, y2)
    if n == 1:
        v = sd.get_vector(start_p, angle2, side_length2, 3)
        v.draw(col, None)
        return geometric_figure(x2, y2, angle2, side_length2, m_n, n + 1, m, m, v, col)
    elif n > m_n:
        return 0
    else:
        v1 = sd.get_vector(v.end_point, angle2 + m2, side_length2, 3)
        v1.draw(col, None)
        if n == m_n -1:
            sd.line(v1.end_point, sd.get_point(x2, y2), col, 3)
            return 0
        return geometric_figure(x2, y2, angle2, side_length2, m_n, n + 1, m, m2 + m, v1, col)
i = 1
while i < int(figure_num):
    i += 1
geometric_figure(400, 250, 0, 100, i + 2, 1, 360 // (i + 2), 0, 0, all_color[int(color_num) - 1])

sd.pause()