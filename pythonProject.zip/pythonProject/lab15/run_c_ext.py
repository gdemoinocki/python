from my_module import func_n_a
import time

if __name__ == '__main__':
    print(func_n_a(10.0, 10.0))