from distutils.core import setup, Extension

setup(
    name="my_module",
    ext_modules=[Extension("my_module", ["c_module.c"])]
)