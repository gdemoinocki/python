from tkinter import *
from tkinter import messagebox
from tkinter.ttk import Button, Combobox, Label
from lab13_pack.rectangle import Rectangle
from lab13_pack.triangle import Triangle
from lab13_pack.trapezoid import Trapezoid
import docx

root = Tk()
root.title("Геометрические фигуры")
root.geometry("800x300")
root.mainloop()

