from peewee import *
#import datetime
import sqlite3

db = SqliteDatabase('db/database_t.db')


class BaseModel(Model):
    id = PrimaryKeyField(unique=True)

    class Meta:
        database = db
        order_by = 'id'


class Post(BaseModel):
    possition_name = CharField()

    class Meta:
        db_table = 'positions'


class Teacher(BaseModel):
    teacher_name = CharField()
    date_of_birth = DateField()
    post_id = ForeignKeyField(Post)
    department_id = ForeignKeyField('department.id')

    class Meta:
        db_table = 'teacher'




class Department(BaseModel):
    department_name = CharField()
    institute = CharField()
    tech_id = ForeignKeyField('teacher.id')

    class Meta:
        db_table = 'department'


# class TeacherDepartment(Model):
#     t = ForeignKeyField(Teacher)
#     d = ForeignKeyField(Department)
#
#     class Meta:
#         database = db
