﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Media;

namespace Dance
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private bool isCorbel = true;
        //private SolidColorBrush defaultColor;
        //private SolidColorBrush defaultColor1;
        //private SolidColorBrush defaultColor2;
        public MainWindow()
        {
            InitializeComponent();
            //defaultColor = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
            //// Устанавливаем изначальный цвет окна
            //Background = defaultColor;
            //defaultColor1 = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#B7968D"));
            //defaultColor1 = defaultColor;
            //defaultColor2 = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#D8D5D2"));
            //defaultColor2 = defaultColor;
        }
        private void ScaleButton_Click(object sender, RoutedEventArgs e)
        {
            
            if (ScaleSlider.Visibility == Visibility.Collapsed)
                ScaleSlider.Visibility = Visibility.Visible;
            else
                ScaleSlider.Visibility = Visibility.Collapsed;
           
        }



        private void Button_Click1(object sender, RoutedEventArgs e)
        {
            MyFrame.Content = new Page1();
            double scale = ScaleSlider.Value;
            myButton.RenderTransform = new ScaleTransform(scale, scale);

        }
        private void Button_Click2(object sender, RoutedEventArgs e)
        {
            MyFrame.Content = new Page2();
            double scale = ScaleSlider.Value;
            myButton1.RenderTransform = new ScaleTransform(scale, scale);

        }
        private void Button_Click3(object sender, RoutedEventArgs e)
        {
            MyFrame.Content = new Page3();
            double scale = ScaleSlider.Value;
            myButton2.RenderTransform = new ScaleTransform(scale, scale);
        }
        private void Button_Click4(object sender, RoutedEventArgs e)
        {
            MyFrame.Content = new Page4();
            double scale = ScaleSlider.Value;
            myButton3.RenderTransform = new ScaleTransform(scale, scale);
        }
        private void Button_Click5(object sender, RoutedEventArgs e)
        {
            MyFrame.Content = new Page5();
            double scale = ScaleSlider.Value;
            myButton4.RenderTransform = new ScaleTransform(scale, scale);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
           if (Im.Visibility == Visibility.Visible)
            {
                Im.Visibility = Visibility.Hidden;
            }
           else
            {
                Im.Visibility = Visibility.Visible;
            }

        }

        private void Glasses_Button(object sender, RoutedEventArgs e)
        {
            if (ButtonsPanel.Visibility == Visibility.Collapsed)
                ButtonsPanel.Visibility = Visibility.Visible;
            else
                ButtonsPanel.Visibility = Visibility.Collapsed;
        }
       
        private void BBackground(object sender, RoutedEventArgs e)
        {
            

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (isCorbel) 
            {
                FontFamily = new FontFamily("Corbel");
            }
            else
            {
                FontFamily = new FontFamily("Times New Roman");
                
            }
            isCorbel = !isCorbel;
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            FontSize = 25;
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            FontSize = 35;
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            FontSize = 45;
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            //if (Background.Equals(defaultColor))
            //{
            //    // Устанавливаем новый цвет окна
                Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
                myButton.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
                myButton1.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
                myButton2.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
                myButton3.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
                myButton4.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
                myButton.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
                myButton1.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
                myButton2.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
                myButton3.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
                myButton4.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
                Txt.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
                el1.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
                el3.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
                el3.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
            //}
            //else
            //{
            //    //Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#B7968D"));
            //    // Иначе устанавливаем изначальный цвет окна
            //    Background = defaultColor;
            //    myButton.Background = defaultColor;
            //    myButton1.Background = defaultColor1;
            //    myButton2.Background = defaultColor1;
            //    myButton3.Background = defaultColor1;
            //    myButton4.Background = defaultColor1;
            //    myButton.Foreground = defaultColor2;
            //    myButton1.Foreground = defaultColor2;
            //    myButton2.Foreground = defaultColor2;
            //    myButton3.Foreground = defaultColor2;
            //    myButton4.Foreground = defaultColor2;

            //}


        }

        private void MyFrame_Navigated(object sender, NavigationEventArgs e)
        {

        }

        private void ScaleSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
           
        }

        private void Button_Click_6(object sender, RoutedEventArgs e)
        {
            //if (Background.Equals(defaultColor))
            //{
                Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
                myButton.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
                myButton1.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
                myButton2.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
                myButton3.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
                myButton4.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
                myButton.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
                myButton1.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
                myButton2.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
                myButton3.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
                myButton4.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
                Txt.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
                el1.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
                el3.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
                el3.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));



            //}


            //else
            //{
            //    Background = defaultColor;
            //    myButton.Background = defaultColor1;
            //    myButton1.Background = defaultColor1;
            //    myButton2.Background = defaultColor1;
            //    myButton3.Background = defaultColor1;
            //    myButton4.Background = defaultColor1;
            //    myButton.Foreground = defaultColor2;
            //    myButton1.Foreground = defaultColor2;
            //    myButton2.Foreground = defaultColor2;
            //    myButton3.Foreground = defaultColor2;
            //    myButton4.Foreground = defaultColor2;
            //}
        }

        private void Button_Click_7(object sender, RoutedEventArgs e)
        {
            //if (Background.Equals(defaultColor))
            //{

                Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#00008b"));
                myButton.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#00008b"));
                myButton1.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#00008b"));
                myButton2.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#00008b"));
                myButton3.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#00008b"));
                myButton4.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#00008b"));
                myButton.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
                myButton1.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
                myButton2.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
                myButton3.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
                myButton4.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
                Txt.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
                el1.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#00008b"));
                el3.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#00008b"));
                el3.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
            //}
            //else
            //{
            //    Background = defaultColor;
            //    myButton.Background = defaultColor1;
            //    myButton1.Background = defaultColor1;
            //    myButton2.Background = defaultColor1;
            //    myButton3.Background = defaultColor1;
            //    myButton4.Background = defaultColor1;
            //    myButton.Foreground = defaultColor2;
            //    myButton1.Foreground = defaultColor2;
            //    myButton2.Foreground = defaultColor2;
            //    myButton3.Foreground = defaultColor2;
            //    myButton4.Foreground = defaultColor2;
            //}
        }

        private void Button_Click_8(object sender, RoutedEventArgs e)
        {
            Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ffffff"));
            myButton.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#B7968D"));
            myButton1.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#B7968D"));
            myButton2.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#B7968D"));
            myButton3.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#B7968D"));
            myButton4.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#B7968D"));
            myButton.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#D8D5D2"));
            myButton1.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#D8D5D2"));
            myButton2.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#D8D5D2"));
            myButton3.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#D8D5D2"));
            myButton4.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#D8D5D2"));
            Txt.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#B7968D"));
            el1.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#B7968D"));
            el3.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#B7968D"));
            el3.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#D8D5D2"));
        }
    }
}

