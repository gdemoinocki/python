﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Dance
{
    /// <summary>
    /// Логика взаимодействия для Page2.xaml
    /// </summary>
    public partial class Page2 : Page
    {
        public Page2()
        {
            InitializeComponent();
        }
        private void Button_Click11(object sender, RoutedEventArgs e)
        {
            MyFrame2.Content = new Page7();
        }
        private void Button_Click22(object sender, RoutedEventArgs e)
        {
            MyFrame1.Content = new Page6();
        }
        private void Button_Click33(object sender, RoutedEventArgs e)
        {
            MyFrame3.Content = new Page8();
        }
        private void Button_Click44(object sender, RoutedEventArgs e)
        {
            MyFrame4.Content = new Page9();
        }
        private void Button_Click55(object sender, RoutedEventArgs e)
        {
            MyFrame5.Content = new Page10();
        }
        private void Button_Click66(object sender, RoutedEventArgs e)
        {
            MyFrame6.Content = new Page11();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(null);
        }

        private void MyFrame4_Navigated(object sender, NavigationEventArgs e)
        {

        }

        private void MyFrame2_Navigated(object sender, NavigationEventArgs e)
        {

        }

        private void MyFrame3_Navigated(object sender, NavigationEventArgs e)
        {

        }

        private void MyFrame5_Navigated(object sender, NavigationEventArgs e)
        {

        }

        private void MyFrame6_Navigated(object sender, NavigationEventArgs e)
        {

        }
    }
}
