from peewee import *
import sqlite3
import datetime
from bd_lab import *


with db:
    db.create_tables([Teacher, Post, Department])
    # post = [
    #     {'possition_name': 'Старший преподаватель'},
    #     {'possition_name': 'Доцент кафедры'},
    #     {'possition_name': 'Преподаватель'},
    # ]
    #
    # Post.insert_many(post).execute()
    #
    # positions = Post.select()
    # teacher = [
    #     {'teacher_name': 'Яблочкин Олег Васильевич', 'date_of_birth': datetime.date(1990, 1, 15), 'post_id': positions[0].id},
    #     {'teacher_name': 'Ткачева Арина Сергеевна', 'date_of_birth': datetime.date(1980, 11, 27), 'post_id': positions[1].id},
    #     {'teacher_name': 'Лень Евгения Филиппова', 'date_of_birth': datetime.date(1974, 5, 15), 'post_id': positions[2].id},
    # ]
    #
    # Teacher.insert_many(teacher).execute()
    # positionss= Teacher.select()
    #
    # department = [
    #     {'department_name': 'АСОИУ', 'institute': 'ПИ', 'tech_id': positionss[0].id},
    #     {'department_name': 'ИИ', 'institute': 'ПИ', 'tech_id': positionss[1].id},
    #     {'department_name': 'ПМ', 'institute': 'ПИ','tech_id': positionss[2].id},
    # ]
    #
    # Department.insert_many(department).execute()

    # tech_d = Teacher.select()
    # depart_t = Department.select()
    #
    # print(tech_d, '\n', depart_t)
    #
    # teacherdepart = [
    #     {'t_id':tech_d.id, 'd_id': depart_t[0].id},
    #     {'t_id': tech_d.id, 'd_id': depart_t[1].id},
    #     {'t_id': tech_d.id, 'd_id': depart_t[2].id}
    # ]
    #
    # def get_time(y, m, d):
    #     return datetime.datetime.timestamp(datetime.datetime(y, m, d))
    #
    #
    # def get_date(tm):
    #     return datetime.datetime.fromtimestamp(tm).date()
    #
    # today = get_date(get_time(2023, 1, 16))
    # allteachers = Teacher.select()
    # allpost = Post.select()
    #
    # lst = []
    # id_post_list = []
    # i = 0
    # f = 0
    # for tech in allteachers:
    #     lst.insert(i, tech.teacher_name)
    #     lst.insert(i+1, str(int((today - tech.date_of_birth) / datetime.timedelta(days=365.25))) + ' лет')
    #     id_post_list.insert(f, tech.id)
    #     i+=2
    #     print(id_post_list)
    #     f+=1
    #
    #
    # j = 2
    # k=0
    #
    # for pst in allpost:
    #     pi = pst.id
    #
    #     if pi != id_post_list[k]:
    #         while (pi) != id_post_list[k]:
    #              pi+=1
    #     lst.insert(j+k, pst.possition_name)
    #     j += 2
    #     k+=1
    #
    # print(lst)

    # alldep = Department.select()
    # k_2 = 0
    # j_2 = 0
    #
    # for dep in alldep:
    #     de = dep.tech_id
    #     if de != id_post_list[k_2]:
    #         while (de) != id_post_list[k_2]:
    #             de += 1
    #     lst.insert(j + k_2, pst.possition_name)
    #     j_2 += 2
    #     k_2 += 1
    #
    # print('Всего', len(allteachers))

# print(tech.teacher_name, int((today - tech.date_of_birth)/datetime.timedelta(days = 365.25)), 'лет')

print('DONE')