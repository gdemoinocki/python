from appJar import gui

# create the GUI & set a title
app = gui("Login Form")

# add labels & entries
# in the correct row & column
app.addLabel("userLab", "Username:", 0, 0)
app.addEntry("userEnt", 0, 1)
app.addSecretEntry("passEnt", 1, 1)
app.addLabel("passLab", "Password:", 1, 0)
#app.addEntry("passEnt", 1, 1)

# start the GUI
#app.addButtons(["Submit", "Cancel"], None, colspan=2)

# unction to print out the name of the button pressed
    # followed by the contents of the two entry boxes

def press(btnName):

    if btnName == "Cancel":
        app.stop()

    elif app.getEntry("userEnt") == "rjarvis":
        if app.getEntry("passEnt") == "abc":
            app.infoBox("Success", "Congratulations, you are logged in!")
        else:
            app.errorBox("Failed login", "Invalid password")
    else:
        app.errorBox("Failed login", "Invalid username")


app.setFocus("userEnt")
app.enableEnter(press)


# changed this line to call a function
app.addButtons( ["Submit", "Cancel"], press, colspan=2)



app.go()