x = int(input('Введите число ')) #Принимаем значение от пользователя
#Объявление перемнных
previous_x = int()
n = int()
min_x = int()

while -1 <= x or -10 >= x:
    previous_x = x
    x = int(input('Введите число '))
    n += 1
    min_x = min(x, previous_x, min_x)#Поиск минимального числа из введенных

print('Количество:', n, '\n','минимум:', min_x)#Вывод результата на экран




