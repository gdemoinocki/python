#!/usr/bin/env python3
# -*- coding: utf-8 -*-

result = 1 * ( 2 + 3 ) + 4 * 5
print(result)