#!/usr/bin/env python3
# -*- coding: utf-8 -*-

secret_message = [
    'квевтфпп6щ3стмзалтнмаршгб5длгуча',
    'дьсеы6лц2бане4т64ь4б3ущея6втщл6б',
    'т3пплвце1н3и2кд4лы12чф1ап3бкычаь',
    'ьд5фму3ежородт9г686буиимыкучшсал',
    'бсц59мегщ2лятьаьгенедыв9фк9ехб1а',
]

a = secret_message[0][3:4:1]
b = secret_message[1][9:13:1]
c = secret_message[2][5:15:2]
d = secret_message[3][12:6:-1]
e = secret_message[4][20:15:-1]

print(a, b, c, d, e)