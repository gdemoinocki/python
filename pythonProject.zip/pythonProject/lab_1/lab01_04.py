#!/usr/bin/env python3
# -*- coding: utf-8 -*-

my_family = ['отец', 'мать', 'сестра', 'бабушка']
my_family_height = [
    [my_family[0], 178],
    [my_family[1], 169],
    [my_family[2], 160],
    [my_family[3], 155]
]

print('рост отца -', my_family_height[0][1], 'см')
print('общий рост моей семьи -', my_family_height[0][1] + my_family_height[1][1] + my_family_height[2][1] + my_family_height[3][1], 'см')
