#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#словарь координат городов

sites = {
    'Moscow': (550, 370),
    'London': (510, 510),
    'Paris': (480, 480),
}
#функция для поиска расстояния между городами

def dis(x1, x2, y1, y2):
    return ((x1 - x2) ** 2 + (y1 - y2) ** 2) ** 0.5

#переменные для заполнения словаря

a1 = (sites['Moscow'][0])
a2 = (sites['Moscow'][1])
b1 = (sites['London'][0])
b2 = (sites['London'][1])
c1 = (sites['Paris'][0])
c2 = (sites['Paris'][1])

#словарь словарей расстояний между ними

distances = dict(Moscow_London = dis(a1, b1, a2, b2),London_Paris = dis(b1, c1, b2, c2), Paris_Moscow = dis(a1, c1, a2, c2));

#вывод словаря

print(distances)