import datetime

post = [
    (1, 'Старший преподаватель'),
    (2, 'Преподаватель'),
    (3, 'Доцент кафедры'),
    (4, 'Старший преподаватель')
]

def get_time(y, m, d):
    return datetime.datetime.timestamp(datetime.datetime(y, m, d))


def get_date(tm):
    return datetime.datetime.fromtimestamp(tm).date()

teachers = [
    (1, 'Яблочкин Олег Васильевич', get_date(get_time(1990, 1, 15))),
    (2, 'Ткачева Арина Сергеевна', get_date(get_time(1980, 11, 27))),
    (3, 'Лень Евгения Филиппова', get_date(get_time(1974, 5, 15))),
    (4, 'Лень Евгения Филиппова', get_date(get_time(1983, 5, 15))),
]

department = [
    (1, 'АСОИУ', 'ПИ'),
    (2, 'ИИ', 'ПИ'),
    (3, 'ПМ', 'ПИ'),
    (4, 'СТИК', 'ПИ'),
]