num = int(input('Введите число '))
max_digit = 0

while num != 0:
    digit = num % 10
    if digit > max_digit:
        max_digit = digit
    num //= 10

if int(max_digit) % 2 == 0:
    print('Число', max_digit,'является четным')
else:
    print('Число', max_digit,'является нечетным')
