def triangle_area(a, h):
    return round(((a * h)/ 2), 2)


def radius_c_circle_trian(a, b, c, h):
    return round((a + b + c) / 4 * triangle_area(a, h), 2)


def radius_i_circle_trian(a, b, c, h):
    return round(triangle_area(a, h) / ((a + b + c) / 2), 2)
