def trapezoid_area(a, b, h):
    return round((h * (a + b)) / 2, 2)


def radius_c_circle_trap(a, b, c, h):
    return round((a + b + c) / 4 * trapezoid_area(a, b, h), 2)


def radius_i_circle_trap(h):
    return round(h/2, 2)
