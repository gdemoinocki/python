import math

def recangle_area(a,b):
    return round(a * b, 2)


def radius_c_circle_rect(a, b):
    return round(math.sqrt(a ** 2 + b ** 2) / 2, 2)


def radius_i_circle_rect(a, b):
    if a == b:
        return round(a / 2)
    return 'окружность не вписывается в прямоугольник'

